
export const ROOT_URL='https://ide-dadeecbacdecbaafcdbbabdbbfebbfbcdeedaee.premiumproject.examly.io/proxy/8080/';







 


