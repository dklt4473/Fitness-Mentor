import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService, USER_ID } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-useraddfeedback',
  templateUrl: './useraddfeedback.component.html',
  styleUrls: ['./useraddfeedback.component.css']
})
export class UseraddfeedbackComponent implements OnInit {

  feedbackForm:FormGroup;

  feedback: any = {
    feedbackText: "",
    date: "",
    user: {
      userId: this.authService.getAuthenticatedUserId()
    }
  };

  constructor(private fb:FormBuilder,private feedbackService:FeedbackService, private router: Router,private authService:AuthService) {
    
  }
  
  ngOnInit(): void {
    this.feedbackForm=this.fb.group({
      feedbackText: ['',[Validators.required]]
    });
  }

  submitFeedback(){
    if (this.feedbackForm.valid) {
      this.feedback.feedbackText = this.feedbackForm.value.feedbackText;
      this.feedback.date = new Date().toISOString().split('T')[0];
      this.feedbackService.sendFeedback(this.feedback).subscribe(
        () => {
          // alert("Feedback Added Successfully");
          this.router.navigate(['/user/viewFeedback']);
        },
        // () => {
        //   alert("Feedback Not Added");
        // }
      );
    }
    this.showSuccessMessage();
  }

  showSuccessMessage(){
    const successMessage=document.getElementById('successMessage');
    successMessage?.classList.add('active');
  }
 
  closeSuccessMessage(){
    this.feedbackForm.reset();
    this.router.navigate(['/admin/viewFeedback']);
    const successMessage=document.getElementById('successMessage');
    successMessage.classList.remove('active'); 
  }
  
}
