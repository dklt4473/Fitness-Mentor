import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-usernav',
  templateUrl: './usernav.component.html',
  styleUrls: ['./usernav.component.css']
})
export class UsernavComponent implements OnInit {

  showTraining:boolean= false;
  showFeedback:boolean=false;
  showModal: boolean = false;

  user:User={
    userId:0,
    email:'',
    password:'',
    username:'',
    mobileNumber:'',
    userRole:''
  }
  toggleTraining(){
    this.showTraining=!this.showTraining;
  }
  toggleFeedback(){
    this.showFeedback=!this.showFeedback;
  }

  showLogoutModal() {
    this.showModal = true;
  }

  confirmLogout() {
    this.showModal = false;
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  cancelLogout() {
    this.showModal = false;
  }
  constructor(private router:Router,private authService:AuthService) { }

  ngOnInit(): void {
    let userId = this.authService.getAuthenticatedUserId();
    this.authService.getUserById(userId).subscribe((data)=>{
      this.user=data;
    });
  }

}
