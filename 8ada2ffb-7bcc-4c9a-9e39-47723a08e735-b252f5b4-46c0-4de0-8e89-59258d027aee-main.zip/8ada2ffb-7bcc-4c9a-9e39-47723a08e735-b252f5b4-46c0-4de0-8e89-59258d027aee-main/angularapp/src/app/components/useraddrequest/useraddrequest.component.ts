import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { PhysicalTrainingRequest } from 'src/app/models/physical-training-request.model';
import { AuthService, USER_ID } from 'src/app/services/auth.service';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';
 
@Component({
  selector: 'app-useraddrequest',
  templateUrl: './useraddrequest.component.html',
  styleUrls: ['./useraddrequest.component.css']
})
export class UseraddrequestComponent implements OnInit {
 
  requestForm: FormGroup;
  isSubmitted: boolean = false;
 
  request: any = {
    comments: '',
    fitnessGoals: '',
    healthConditions: '',
    requestDate: '',
    status: 'Pending',
    physicalTraining: {
      physicalTrainingId: 0
    },
    user: {
      userId: 0
    }
  }
  ngOnInit(): void {
    this.request.physicalTraining.physicalTrainingId=parseInt(this.route.snapshot.params['id']);
    this.requestForm = this.formBuilder.group({
      healthConditions: ['', Validators.required],
      fitnessGoals: ['', Validators.required],
      comments: ['']
    });
  }
  constructor(private physicalTraining: PhysicalTrainingService, private router: Router, private formBuilder: FormBuilder,private route:ActivatedRoute, private userService : AuthService) {
  }
 
  get f() {
    return this.requestForm.controls;
  }
 
  addUserRequest() {
    this.isSubmitted = true;
    let today = new Date();
    let formattedDate = today.toISOString().split('T')[0];
    let val:any =this.requestForm.value;
    this.request.comments=val.comments;
    this.request.fitnessGoals=val.fitnessGoals;
    this.request.healthConditions=val.healthConditions;
    this.request.requestDate=formattedDate;
    this.request.user.userId = this.userService.getAuthenticatedUserId();
    console.log(JSON.stringify(this.request));
    this.physicalTraining.addPhysicalTrainingRequest(this.request).subscribe((data) => {
      this.router.navigate(['/user/viewRequest']);
    });
    this.showSuccessMessage();
   
  }
 
  back() {
    this.router.navigate(['/user/viewTraining']);
  }
 
  showSuccessMessage(){
    const successMessage=document.getElementById('successMessage');
    successMessage?.classList.add('active');
  }
 
  closeSuccessMessage(){
    this.requestForm.reset();
    this.router.navigate(['/user/viewRequest']);
    const successMessage=document.getElementById('successMessage');
    successMessage.classList.remove('active');
  }
}
 
 