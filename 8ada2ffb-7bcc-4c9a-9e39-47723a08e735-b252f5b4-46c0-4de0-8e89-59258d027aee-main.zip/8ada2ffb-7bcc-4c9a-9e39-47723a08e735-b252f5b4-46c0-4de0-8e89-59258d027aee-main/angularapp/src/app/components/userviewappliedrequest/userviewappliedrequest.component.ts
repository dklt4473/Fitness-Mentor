import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';

@Component({
  selector: 'app-userviewappliedrequest',
  templateUrl: './userviewappliedrequest.component.html',
  styleUrls: ['./userviewappliedrequest.component.css']
})
export class UserviewappliedrequestComponent implements OnInit {
  show = false;
  lowerHalf: any;
  training: any;
  search: string = '';
  userId: number = 0;
  appliedrequest: any[] = [];

  constructor(private service: PhysicalTrainingService, private userService: AuthService) {}

  ngOnInit(): void {
    this.userId = this.userService.getAuthenticatedUserId();
    this.getAllPhysicalTrainingRequestsByUserId();
  }

  getAllPhysicalTrainingRequestsByUserId() {
    this.service.getPhysicalTrainingRequestsByUserId(this.userId).subscribe((data) => {
      this.appliedrequest = data;
    });
  }

  delete(id: number) {
    this.service.deletePhysicalTrainingRequest(id).subscribe(() => {
      this.ngOnInit();
    });
  }

  showRequest(request: any) {
    this.show = true;
    this.lowerHalf = {
      healthConditions: request.healthConditions,
      fitnessGoals: request.fitnessGoals,
      comments: request.comments,
      rejectionReason: request.rejectionReason,
      status: request.status
    };
    this.training = request.physicalTraining;
  }

  showDeleteAlert() {
    alert("Cannot delete, already approved.");
  }

  style(status: string) {
    status = status.toLowerCase();
    if (status === 'approved') {
      return 'green';
    } else if (status === 'rejected') {
      return 'red';
    } else {
      return 'yellow';
    }
  }

  back(): void {
    this.show = false;
  }

  isDeleteDisabled(status: string): boolean {
    return status.toLowerCase() === 'approved';
  }

  isRequestDisabled(trainingName: string): boolean {
    return this.appliedrequest.some(req => req.physicalTraining.trainingName === trainingName && req.status.toLowerCase() === 'approved');
  }
}
