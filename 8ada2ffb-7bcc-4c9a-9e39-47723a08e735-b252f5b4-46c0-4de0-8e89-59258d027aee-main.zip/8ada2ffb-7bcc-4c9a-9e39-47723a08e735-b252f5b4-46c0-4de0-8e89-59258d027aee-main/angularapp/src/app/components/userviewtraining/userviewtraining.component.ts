import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PhysicalTraining } from 'src/app/models/physical-training.model';
import { PhysicalTrainingService } from 'src/app/services/physical-training.service';

@Component({
  selector: 'app-userviewtraining',
  templateUrl: './userviewtraining.component.html',
  styleUrls: ['./userviewtraining.component.css']
})
export class UserviewtrainingComponent implements OnInit {

  constructor(private physicalTraining:PhysicalTrainingService,private router:Router) { }
  userTrainings:PhysicalTraining[]=[];
  searchTerm:string='';

  ngOnInit(): void {
    this.getUserTrainings();
  }

  getUserTrainings(){
    this.physicalTraining.getAllPhysicalTrainings().subscribe((data)=>{
      this.userTrainings = data;
    });
  }

  apply(id:number){
    this.router.navigate(['/user/addRequest',id]);
  }

}
