import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Feedback } from 'src/app/models/feedback.model';
import { AuthService, USER_ID } from 'src/app/services/auth.service';
import { FeedbackService } from 'src/app/services/feedback.service';

@Component({
  selector: 'app-userviewfeedback',
  templateUrl: './userviewfeedback.component.html',
  styleUrls: ['./userviewfeedback.component.css']
})
export class UserviewfeedbackComponent implements OnInit {
  userId:number=0;
  feedbacks: Feedback[] = [];
  showModal: boolean = false;
  showTraining: boolean = false;
  fId: any;

  constructor(private feedbackService: FeedbackService, private authService: AuthService, private router: Router) { }

  loadFeedbacks() {
    this.feedbackService.getAllFeedbacksByUserId(this.userId).subscribe(data => {
      this.feedbacks = data;
    });
  }

  deleteFeedback(id) {
    this.feedbackService.deleteFeedback(id).subscribe((data) => {
      this.ngOnInit();
    });
  }

  ngOnInit(): void {
    this.userId=this.authService.getAuthenticatedUserId();
    this.loadFeedbacks();
  }

  toggleTraining() {
    this.showTraining = !this.showTraining;
  }

  
}
