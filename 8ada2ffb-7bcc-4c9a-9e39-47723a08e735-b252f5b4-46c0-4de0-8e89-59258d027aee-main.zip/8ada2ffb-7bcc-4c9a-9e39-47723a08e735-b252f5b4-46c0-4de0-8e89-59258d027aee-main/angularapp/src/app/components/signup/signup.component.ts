// import { Component, OnInit } from '@angular/core';
// import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
// import { Router } from '@angular/router';
// import { User } from 'src/app/models/user.model';
// import { AuthService } from 'src/app/services/auth.service';

// @Component({
//   selector: 'app-signup',
//   templateUrl: './signup.component.html',
//   styleUrls: ['./signup.component.css']
// })
// export class SignupComponent implements OnInit {
//   registerForm: FormGroup;
//   users: User[] = [];
//   passwordMismatch: boolean = false;
//   showSuccessPopup: boolean = false;
//   errorPopup: boolean = false;
//   constructor(private fb: FormBuilder, private service: AuthService, private router: Router) {
//     this.registerForm = this.fb.group({
//       username: ['', Validators.required],
//       email: ['', [Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)]],
//       password: ['', [Validators.required, this.isPasswordComplex(), Validators.minLength(8)]],
//       confirmPassword: ['', [Validators.required]],
//       mobileNumber: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
//       userRole: ['', Validators.required]
//     });
//   }

//   onSubmit() {
//     if (this.registerForm.valid) {
//       this.service.registerUser(this.registerForm.value).subscribe((result) => {
//         this.registerForm.reset();
//         this.showSuccessPopup = true;
//       },
//         (error) => {
//           this.errorPopup = true;
//           this.registerForm.reset();
//         });
//     }
//   }

//   closePopup() {
//     this.showSuccessPopup = false;
//     this.router.navigate(['/login']);
//   }
//   closepop() {
//     this.errorPopup = false;
//     this.router.navigate(['/signup']);
//   }
//   ngOnInit(): void { }

//   isPasswordComplex(): ValidatorFn {
//     return (control: AbstractControl): { [key: string]: any } | null => {
//       const value = control.value;

//       if (!value) {
//         return null;
//       }

//       const hasUpperCase = /[A-Z]/.test(value);
//       const hasLowerCase = /[a-z]/.test(value);
//       const hasNumber = /[0-9]/.test(value);
//       const hasSpecialCharacter = /[!@#$%^&*(),.?":{}|<>]/.test(value);

//       const passwordValid = hasUpperCase && hasLowerCase && hasNumber && hasSpecialCharacter;

//       return !passwordValid ? { passwordComplexity: true } : null;
//     };
//   }

//   get f() {
//     return this.registerForm.controls;
//   }
// }
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  registerForm: FormGroup;
  users: User[] = [];
  passwordMismatch: boolean = false;
  showSuccessPopup: boolean = false;
  errorPopup: boolean = false;
  errorMessage: string = '';
  validEmployeeIds: string[] = ['EMP123', 'EMP456', 'EMP789', 'EMP101', 'EMP202']; // Prepopulated valid employee IDs

  constructor(private fb: FormBuilder, private service: AuthService, private router: Router) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/)]],
      password: ['', [Validators.required, this.isPasswordComplex(), Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]],
      mobileNumber: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      userRole: ['', Validators.required],
      employeeId: ['', [this.employeeIdPatternValidator()]] // Add employeeId field with pattern validator
    }, {
      validators: this.employeeIdValidator()
    });
  }

  onSubmit() {
    if (this.registerForm.valid) {
      this.service.registerUser(this.registerForm.value).subscribe((result) => {
        this.registerForm.reset();
        this.showSuccessPopup = true;
      }, (error) => {
        if (error === 'UserAlreadyExists') {
          this.errorMessage = 'User already exists!';
        } else {
          this.errorMessage = 'An unexpected error occurred.';
        }
        this.errorPopup = true;
        this.registerForm.reset();
      });
    }
  }

  closePopup() {
    this.showSuccessPopup = false;
    this.router.navigate(['/login']);
  }

  closepop() {
    this.errorPopup = false;
    this.router.navigate(['/signup']);
  }

  ngOnInit(): void { }

  isPasswordComplex(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const value = control.value;
      if (!value) {
        return null;
      }
      const hasUpperCase = /[A-Z]/.test(value);
      const hasLowerCase = /[a-z]/.test(value);
      const hasNumber = /[0-9]/.test(value);
      const hasSpecialCharacter = /[!@#$%^&*(),.?":{}|<>]/.test(value);
      const passwordValid = hasUpperCase && hasLowerCase && hasNumber && hasSpecialCharacter;
      return !passwordValid ? { passwordComplexity: true } : null;
    };
  }

  employeeIdPatternValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const value = control.value;
      const validFormat = /^EMP\d{3,5}$/; // Regular expression to match EMP followed by 3-5 digits
      return value && !validFormat.test(value) ? { invalidEmployeeIdFormat: true } : null;
    };
  }

  employeeIdValidator(): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } | null => {
      const role = control.get('userRole')?.value;
      const employeeId = control.get('employeeId')?.value;
      if (role === 'Admin' && !this.validEmployeeIds.includes(employeeId)) {
        return { invalidEmployeeId: true };
      }
      return null;
    };
  }

  get f() {
    return this.registerForm.controls;
  }
}
