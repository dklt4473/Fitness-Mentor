import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'userSearch'
})
export class UserSearchPipe implements PipeTransform {

  transform(value: any[],term:string,columns:string[]): unknown {
    if(!term||!value){
      return value;
    }

    term = term.toLowerCase().toString();
    
    return value.filter((items)=>{
      return columns.some((column)=>{
        return items.physicalTraining[column]?.toString().toLowerCase().includes(term);
      });
    });

  }

}
