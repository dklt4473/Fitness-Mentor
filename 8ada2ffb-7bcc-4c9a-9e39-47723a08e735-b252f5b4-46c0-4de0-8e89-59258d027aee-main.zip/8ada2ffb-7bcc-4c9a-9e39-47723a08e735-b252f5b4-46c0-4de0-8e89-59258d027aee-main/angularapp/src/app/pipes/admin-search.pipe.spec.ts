import { AdminSearchPipe } from './admin-search.pipe';

describe('AdminSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new AdminSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
