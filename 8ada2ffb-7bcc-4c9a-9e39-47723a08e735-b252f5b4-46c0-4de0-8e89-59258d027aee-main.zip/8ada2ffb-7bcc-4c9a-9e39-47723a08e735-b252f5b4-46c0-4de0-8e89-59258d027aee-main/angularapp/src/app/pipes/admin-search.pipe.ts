import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'adminSearch'
})
export class AdminSearchPipe implements PipeTransform {

  transform(value: any[] , searchTerm:string , columns:string[]): unknown {
    if(!searchTerm||!value){
      return value;
    }

    searchTerm = searchTerm.toLowerCase();
    
    return value.filter((items)=>{
      return columns.some((column)=>{
        if(column == "trainingName") {
          return items.physicalTraining[column].toString().toLowerCase().includes(searchTerm);
        }
      });
    });
  }

}
