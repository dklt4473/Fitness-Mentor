import { AdminFilterPipe } from './admin-filter.pipe';

describe('AdminFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AdminFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
