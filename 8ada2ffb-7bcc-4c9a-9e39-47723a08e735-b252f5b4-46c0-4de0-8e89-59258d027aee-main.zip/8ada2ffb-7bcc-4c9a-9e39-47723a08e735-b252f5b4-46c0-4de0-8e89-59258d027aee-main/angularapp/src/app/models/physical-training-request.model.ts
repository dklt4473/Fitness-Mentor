import { User } from './user.model';
import { PhysicalTraining } from './physical-training.model';

export interface PhysicalTrainingRequest {
  physicalTrainingRequestId?: number;
  requestDate: string;
  status: string;
  healthConditions: string;
  fitnessGoals: string;
  comments: string;
  rejectionReason?: string;
  user: User;
  physicalTraining: PhysicalTraining;
}
