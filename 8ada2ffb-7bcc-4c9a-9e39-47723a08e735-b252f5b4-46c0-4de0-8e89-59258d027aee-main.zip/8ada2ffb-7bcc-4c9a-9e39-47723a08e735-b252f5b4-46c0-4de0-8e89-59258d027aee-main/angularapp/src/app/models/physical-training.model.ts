export interface PhysicalTraining {
    physicalTrainingId?: number;
    trainingName: string;
    trainerName: string;
    location: string;
    isIndoor: boolean;
    fee: number;
    focusArea: string;
    physicalRequirements: string;
    description?: string;
  }
  