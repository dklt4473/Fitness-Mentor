export interface Feedback{
    feedbackId?: number;
    userId: number;
    feedbackText: string;
    date: Date;
}